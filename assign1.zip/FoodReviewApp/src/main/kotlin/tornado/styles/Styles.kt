package tornado.styles

import tornadofx.*

class Styles : Stylesheet() {

}