package food.review.app.console.main

import food.review.app.console.controllers.FoodReviewController

fun main() {
    FoodReviewController().start()
}