
rootProject.name = "placemark-console"

